import os
from PIL import Image
import traceback

# Set the desired output format here
new_format = "png"  # Options: JPG, JPEG, PNG, ICO

def format_file_size(size_in_bytes):
    """
    Convert bytes to a readable format with one decimal place
    """
    size_kb = size_in_bytes / 1024
    return f"{size_kb:.1f}"

def convert_images():
    """
    Convert images in the 'Images' folder to the specified format
    """
    # Supported input formats with normalized handling
    supported_formats = ['JPG', 'JPEG', 'PNG', 'ICO']
    
    # Normalize the format
    normalized_format = 'JPEG' if new_format.upper() in ['JPG', 'JPEG'] else new_format.upper()
    
    # Validate input format
    if normalized_format not in ['JPEG', 'PNG', 'ICO']:
        print(f"Error: Unsupported format {new_format}. Supported formats are: {', '.join(supported_formats)}")
        return
    
    # Path to Images folder
    images_folder = 'Images'
    
    # Check if Images folder exists
    if not os.path.exists(images_folder):
        print(f"Error: '{images_folder}' folder not found in the current directory.")
        return
    
    # Counter for converted images
    converted_count = 0
    error_count = 0
    
    # Iterate through files in the Images folder
    for filename in os.listdir(images_folder):
        try:
            # Construct full file path
            filepath = os.path.join(images_folder, filename)
            
            # Skip if it's a directory
            if os.path.isdir(filepath):
                continue
            
            # Open the image
            with Image.open(filepath) as img:
                # Determine the current format
                current_format = img.format
                
                # Store original file size
                original_size = os.path.getsize(filepath)
                
                # Check if already in the desired format
                if current_format == normalized_format:
                    print(f"Skipping {filename}: Already in {normalized_format} format")
                    continue
                
                # Construct new filename
                new_filename = f"{os.path.splitext(filename)[0]}.{normalized_format.lower()}"
                new_filepath = os.path.join(images_folder, new_filename)
                
                # Convert and save the image
                print(f"Converting {filename} to {normalized_format}")
                
                # Special handling for different formats
                if normalized_format == 'ICO':
                    # Convert to RGBA for ICO
                    img = img.convert('RGBA')
                    img.save(new_filepath, format='ICO', sizes=[(16,16), (32,32), (48,48), (64,64)])
                elif normalized_format == 'JPEG':
                    # Convert to RGB and optimize for smaller file size
                    img_rgb = img.convert('RGB')
                    img_rgb.save(new_filepath, format='JPEG', optimize=True, quality=85)
                else:
                    # For PNG, preserve transparency
                    img.save(new_filepath, format=normalized_format)
                
                # Get new file size
                new_size = os.path.getsize(new_filepath)
                
                # Format file sizes in KB with one decimal place
                formatted_original_size = format_file_size(original_size)
                formatted_new_size = format_file_size(new_size)
                
                # Calculate and print file size comparison
                size_reduction = (1 - new_size / original_size) * 100
                print(f"File sizes: {formatted_original_size} _ {formatted_new_size} (Reduced by {size_reduction:.2f}%)")
                
                # Remove the original file AFTER saving the new one
                os.remove(filepath)
                
                converted_count += 1
                print(f"Converted {filename} to {normalized_format}")
        
        except Exception as e:
            print(f"Error converting {filename}: {str(e)}")
            print(traceback.format_exc())
            error_count += 1
    
    # Final summary
    print("\n--- Conversion Complete ---")
    print(f"Total images converted: {converted_count}")
    print(f"Errors encountered: {error_count}")

# Run the conversion
convert_images()


