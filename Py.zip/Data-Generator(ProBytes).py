
def generate_price_list(base_price):
    multipliers = [1, 2, 3, 5, 7, 10]
    return [f"&#8358;{format(base_price * m, ',')}" for m in multipliers]

default_price = 350
airtel_price = 320
glo_price = 260
nine_mobile_price = 220

# Generating price lists
print(f'let defaultPrices = {generate_price_list(default_price)};')
print(f'let airtelPrices = {generate_price_list(airtel_price)};')
print(f'let gloPrices = {generate_price_list(glo_price)};')
print(f'let nineMobilePrices = {generate_price_list(nine_mobile_price)};')

