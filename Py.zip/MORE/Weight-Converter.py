
def kg_to_lbs():
    kg_to_lbs = number * 2.20462
    print(f"{number:,.1f} kg in Pounds is {kg_to_lbs:,.1f} lbs!")

def lbs_to_kg():
    lbs_to_kg = number / 2.20462
    print(f"{number:,.1f} lbs in Kilograms is {lbs_to_kg:,.1f} kg!")

def kg_to_tons():
    kg_to_tons = number / 1000
    print(f"{number:,.1f} kg in Tons is {kg_to_tons:,.1f} tons!")

def lbs_to_tons():
    lbs_to_tons = number / 2204.62
    print(f"{number:,.1f} lbs in Tons is {lbs_to_tons:,.1f} tons!")

def tons_to_kg():
    tons_to_kg = number * 1000
    print(f"{number:,.1f} tons in Kilograms is {tons_to_kg:,.1f} kg!")

def tons_to_lbs():
    tons_to_lbs = number * 2204.62
    print(f"{number:,.1f} tons in Pounds is {tons_to_lbs:,.1f} lbs!")





print("Unit converter")

while True:
    try:
        number = float(input("\nEnter a number: "))
        my_input = input("(Kg, Lbs, Tons) My input is in: ").strip().lower()
        cover_to = input("I want to convert it to: ").strip().lower()

        if (my_input == "kg" or my_input == "k") and (cover_to == "lbs" or cover_to == "l"):
            kg_to_lbs()

        elif (my_input == "lbs" or my_input == "l") and (cover_to == "kg" or cover_to == "k"):
            lbs_to_kg()

        elif (my_input == "kg" or my_input == "k") and (cover_to == "tons" or cover_to == "t"):
            kg_to_tons()

        elif (my_input == "lbs" or my_input == "l") and (cover_to == "tons" or cover_to == "t"):
            lbs_to_tons()

        elif (my_input == "tons" or my_input == "t") and (cover_to == "kg" or cover_to == "k"):
            tons_to_kg()

        elif (my_input == "tons" or my_input == "t") and (cover_to == "lbs" or cover_to == "l"):
            tons_to_lbs()

        else:
            print("Invalid input!")

    except ValueError:
        print("Invalid input. Enter a number.!")







