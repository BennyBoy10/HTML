
import requests
from bs4 import BeautifulSoup
import os

# URL of the page to scrape
url = 'https://URL'

# Fetch the page
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# Try to find video URLs
video_urls = []

# Check for <video> tags
for video in soup.find_all('video'):
    source = video.find('source')
    if source and 'src' in source.attrs:
        video_urls.append(source['src'])

# Check for <iframe> tags
for iframe in soup.find_all('iframe'):
    if 'src' in iframe.attrs:
        video_urls.append(iframe['src'])

# Check for <a> tags that might link to videos
for a in soup.find_all('a', href=True):
    if 'video' in a['href']:  # Adjust this condition based on actual HTML
        video_urls.append(a['href'])

# Filter out empty URLs
video_urls = [url for url in video_urls if url]

# Print the found URLs for debugging
print(f'Found video URLs: {video_urls}')

# Download videos if any URLs were found
if not video_urls:
    print('No video URLs found on the page.')
else:
    # Create downloads directory if it doesn't exist
    if not os.path.exists('downloads'):
        os.makedirs('downloads')

    # Download each video
    for i, video_url in enumerate(video_urls):
        # Check if the URL is complete
        if not video_url.startswith('http'):
            video_url = 'https:' + video_url

        video_name = f"video_{i+1}.mp4"

        print(f'Downloading {video_name} from {video_url}...')
        
        try:
            video_response = requests.get(video_url)
            video_response.raise_for_status()  # Check for HTTP errors
            
            with open(f'downloads/{video_name}', 'wb') as file:
                file.write(video_response.content)
                
            print(f'Successfully downloaded {video_name}')
        except requests.exceptions.RequestException as e:
            print(f'Failed to download {video_name}: {e}')

    print('Download complete!')


