
from pytube import YouTube

url = input("Enter the YouTube video URL: ")

# Step 3: Download the video
try:
# Create a YouTube object with the URL
    yt = YouTube(url)

# Get the highest resolution stream available
    stream = yt.streams.get_highest_resolution()

    # Download the video
    print("Downloading...")
    stream.download()

    print("Download completed!")
except Exception as e:
    print("An error occurred:", e)







