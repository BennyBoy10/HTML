import os
import sys
import json
import tempfile
from typing import Any, List, Tuple

INPUT_PATH = os.path.join("JSON", "emails.json")
OUTPUT_PATH = INPUT_PATH # overwrite the same file
JSON_KEY = "emailAddresses"
LOWERCASE_ALL = True

colors = {
    "reset": '\x1b[0m',
    "bright": '\x1b[1m',
    "green": '\x1b[32m',
    "yellow": '\x1b[33m',
    "blue": '\x1b[34m',
    "magenta": '\x1b[35m',
    "cyan": '\x1b[36m',
    "red": '\x1b[31m',
    "white": '\x1b[37m'
}
# ----------------------------------------

# ---- small colored logger helpers ----
def info(msg: str):
    print(f"{colors['cyan']}ℹ️  {msg}{colors['reset']}")

def success(msg: str):
    print(f"{colors['green']}✅ {msg}{colors['reset']}")

def warn(msg: str):
    print(f"{colors['yellow']}⚠️  {msg}{colors['reset']}")

def error(msg: str):
    print(f"{colors['red']}❌ {msg}{colors['reset']}")

def headline(title: str):
    print(f"{colors['magenta']}{colors['bright']}{title}{colors['reset']}")

# ---- file helpers ----
def safe_open(path: str, mode: str, encodings=("utf-8", "utf-8-sig", "latin-1")):
    """Open using multiple encodings, raising the last exception if all fail."""
    last_exc = None
    for enc in encodings:
        try:
            return open(path, mode, encoding=enc)
        except Exception as e:
            last_exc = e
    raise last_exc

def ensure_dir_exists(path: str):
    """Ensure directory for given path exists."""
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        try:
            os.makedirs(d, exist_ok=True)
            success(f"Created folder: {d}")
        except Exception as e:
            error(f"Failed to create folder {d}: {e}")
            raise

def write_json_atomic(path: str, data: Any):
    """Write JSON atomically to avoid partial writes/corruption."""
    ensure_dir_exists(path)
    tmp_fd, tmp_path = tempfile.mkstemp(prefix="._tmp_json_", dir=os.path.dirname(path) or ".")
    os.close(tmp_fd)
    try:
        with open(tmp_path, "w", encoding="utf-8") as tf:
            json.dump(data, tf, indent=1, ensure_ascii=False)
        os.replace(tmp_path, path)
        success(f"Wrote output to: {path}")
    except Exception as e:
        error(f"Failed to write output: {e}")
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass
        raise

# ---- core logic ----
def load_json_file(path: str) -> Tuple[Any, List[str]]:
    """Load JSON and return raw object. Returns (data, errors)."""
    errors = []
    try:
        with safe_open(path, "r") as f:
            data = json.load(f)
        info(f"Loaded JSON from: {path}")
        return data, errors
    except FileNotFoundError:
        error(f"Input file not found: {path}")
        return None, errors + [f"FileNotFound: {path}"]
    except json.JSONDecodeError as jde:
        error(f"JSON decode error in {path}: {jde}")
        return None, errors + [f"JSONDecodeError: {jde}"]
    except Exception as e:
        error(f"Failed to read {path}: {e}")
        return None, errors + [f"ReadError: {e}"]

def extract_email_list_from_json(obj: Any) -> Tuple[List[str], List[str]]:
    """
    Given loaded JSON 'obj', extract the email list according to the two allowed input shapes:
      - object with a single array value (or multiple keys but take the first array value)
      - raw array
    Returns (emails_list, errors)
    """
    errors = []
    if obj is None:
        errors.append("No JSON object provided")
        return [], errors

    # Case A: raw list
    if isinstance(obj, list):
        if all(isinstance(x, str) for x in obj):
            return obj, errors
        else:
            # attempt to stringify non-string items carefully
            emails = []
            for i, v in enumerate(obj):
                try:
                    emails.append(str(v))
                except Exception as e:
                    errors.append(f"ItemConversionError at index {i}: {e}")
            return emails, errors

    # Case B: dict/object
    if isinstance(obj, dict):
        # Find the first value that is a list of strings (or list)
        for key, val in obj.items():
            if isinstance(val, list):
                # convert all items to string (best-effort)
                emails = []
                for i, item in enumerate(val):
                    if isinstance(item, str):
                        emails.append(item)
                    else:
                        try:
                            emails.append(str(item))
                        except Exception as e:
                            errors.append(f"Key '{key}' - item {i} conversion failed: {e}")
                info(f"Extracted email list from key: '{key}' (will be rewritten to '{JSON_KEY}')")
                return emails, errors
        # No list found in object — treat as empty (per your rule: skip/continue)
        warn("No array value found in JSON object — treating as empty list")
        return [], errors

    # Otherwise unsupported type
    warn(f"Unsupported JSON root type: {type(obj)} — treating as empty list")
    return [], errors

def process_emails(emails: List[str]) -> Tuple[List[str], int, List[Tuple[int, str]]]:
    """
    Process emails:
      - trim whitespace
      - lowercase (if configured)
      - dedupe preserving first-seen order
      - sort alphabetically
    Returns (final_sorted_list, original_count, errors_list)
    """
    errors = []
    original_count = len(emails)
    info(f"Processing {original_count} email entries...")

    if original_count == 0:
        warn("No emails to process.")
        return [], 0, errors

    seen = set()
    cleaned = []
    percent_step = 10
    next_percent = percent_step
    processed = 0

    for idx, raw in enumerate(emails, start=1):
        try:
            if raw is None:
                processed += 1
                continue

            email = raw.strip()
            if LOWERCASE_ALL:
                email = email.lower()

            # Skip empty strings
            if email == "":
                processed += 1
                # progress print
                pct = (processed / original_count) * 100
                while pct >= next_percent and next_percent <= 100:
                    print(f"{colors['yellow']}{int(next_percent)}% Done{colors['reset']}")
                    next_percent += percent_step
                continue

            if email not in seen:
                seen.add(email)
                cleaned.append(email)

            processed += 1
            pct = (processed / original_count) * 100
            while pct >= next_percent and next_percent <= 100:
                print(f"{colors['yellow']}{int(next_percent)}% Done{colors['reset']}")
                next_percent += percent_step

        except Exception as e:
            errors.append((idx, str(raw)[:120], str(e)))
            processed += 1
            pct = (processed / original_count) * 100
            while pct >= next_percent and next_percent <= 100:
                print(f"{colors['yellow']}{int(next_percent)}% Done{colors['reset']}")
                next_percent += percent_step

    # ensure remaining percents printed
    if next_percent <= 100:
        for p in range(int(next_percent), 101, percent_step):
            print(f"{colors['yellow']}{p}% Done{colors['reset']}")

    # Sort the unique list alphabetically
    try:
        final_sorted = sorted(cleaned)
    except Exception as e:
        error(f"Sorting failed: {e} — returning unsorted unique list")
        final_sorted = cleaned

    return final_sorted, original_count, errors

# ---- main ----
def main():
    headline("JSON Email Organizer — Starting")
    info(f"Input file: {INPUT_PATH}")
    info(f"Output file: {OUTPUT_PATH}")
    info(f"Save key: '{JSON_KEY}'")
    info(f"Lowercase all: {LOWERCASE_ALL}")

    data, load_errors = load_json_file(INPUT_PATH)
    if load_errors:
        # If file missing -> exit (there's nothing to overwrite). If JSON malformed -> exit.
        # You asked "If a JSON is missing it should skip it and continue" — but here we have one file.
        # We'll exit with proper error messages.
        if data is None:
            error("Aborting due to input read error.")
            # still print load errors
            for le in load_errors:
                error(f"LoadError: {le}")
            return

    raw_emails, extract_errors = extract_email_list_from_json(data)
    if extract_errors:
        for e in extract_errors:
            warn(f"Extraction warning: {e}")

    final_list, original_count, proc_errors = process_emails(raw_emails)

    duplicates_removed = original_count - len(final_list)

    payload = {JSON_KEY: final_list}

    try:
        write_json_atomic(OUTPUT_PATH, payload)
    except Exception as e:
        error(f"Failed to save final JSON: {e}")
        return

    # ---- SUMMARY ----
    print(f"{colors['blue']}{'='*48}{colors['reset']}")
    headline("📋 SUMMARY")
    print(f"{colors['blue']}{'='*48}{colors['reset']}")

    success(f"Original entries found: {original_count}")
    success(f"Final unique emails saved: {len(final_list)}")
    warn(f"Duplicates removed: {duplicates_removed}")

    if proc_errors:
        error(f"Processing errors encountered: {len(proc_errors)}")
        for idx, preview, msg in proc_errors[:10]:
            error(f"- Index {idx}: {msg} (preview: {preview!r})")
        if len(proc_errors) > 10:
            error(f"- ...and {len(proc_errors)-10} more processing errors")
    else:
        success("No processing errors encountered")

    if load_errors:
        warn(f"Load warnings/errors: {len(load_errors)}")
        for le in load_errors:
            warn(f"- {le}")

    if extract_errors:
        warn(f"Extraction warnings: {len(extract_errors)}")

    info(f"JSON saved to: {OUTPUT_PATH}")
    print()  # extra line for neatness

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        warn("Interrupted by user (KeyboardInterrupt). Exiting.")
        sys.exit(2)
    except Exception as fatal:
        error(f"Fatal error: {fatal}")
        sys.exit(1)


