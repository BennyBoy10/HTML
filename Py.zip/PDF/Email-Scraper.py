import asyncio
import aiohttp
import re
import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import signal
import sys
from datetime import datetime, timedelta
from collections import deque

from bs4 import XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)


URL = "https://myschool.ng/questions/view/academic-questions/351373"
fileName = "JSON/mySchoolEmails.json"
scrapedPagesFile = "JSON/scrappedPages.json"

stay_in_domain = True
max_concurrent_requests = 50  # 5–50
batchSize = 500
max_depth = 10000  # How many clicks deep to go, suggested 3–10
max_urls = 100000  # Optional: max URLs to scrape, prevents "run wild forever"

# =========================
# Regex
# =========================
EMAIL_FULL_RE = re.compile(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,24}$', re.I)
EMAIL_FIND_RE = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,24}', re.I)

# =========================
# Global Containers
# =========================
visited_pages = set()
emails_found = set()
scrapped_pages = {}   # {url: email_count}
url_queue = deque()
stop_scraping = False

# =========================
# Signal handler for Ctrl+C
# =========================
def signal_handler(sig, frame):
    global stop_scraping
    print("\n⚠️ Ctrl+C detected! Saving progress before exiting…")
    stop_scraping = True

signal.signal(signal.SIGINT, signal_handler)

# =========================
# Email Cleaning Function
# =========================
def clean_email(raw: str):
    s = raw.lower()
    s = s.replace("[at]", "@").replace("(at)", "@")
    s = s.strip(" <>[]()'\":;,.")
    return s if EMAIL_FULL_RE.fullmatch(s) else None

# =========================
# Fetch page asynchronously
# =========================
async def fetch_page(session, url):
    global stop_scraping
    try:
        async with session.get(url, timeout=15, headers={"User-Agent": "Mozilla/5.0"}) as r:
            r.raise_for_status()
            text = await r.text()
            return text
    except Exception as e:
        print(f"❌ Failed to fetch {url}: {e}")
        return None

# =========================
# Extract emails & links from HTML
# =========================
def parse_page(html, base_url):
    page_emails = set()
    page_links = set()

    soup = BeautifulSoup(html, "html.parser")

    # 1. Mailto links
    for a in soup.select('a[href^="mailto:"]'):
        raw = a['href'].split(":", 1)[1].split("?", 1)[0]
        cleaned = clean_email(raw)
        if cleaned:
            page_emails.add(cleaned)

    # 2. Emails in href
    for a in soup.find_all(href=True):
        for match in EMAIL_FIND_RE.findall(a['href']):
            cleaned = clean_email(match)
            if cleaned:
                page_emails.add(cleaned)
        # Add link
        href = a['href']
        abs_link = urljoin(base_url, href)
        page_links.add(abs_link)

    # 3. Emails in visible text
    text = soup.get_text(" ")
    for match in EMAIL_FIND_RE.findall(text):
        cleaned = clean_email(match)
        if cleaned:
            page_emails.add(cleaned)

    return page_emails, page_links

# =========================
# Crawl worker
# =========================
async def worker(session, depth):
    global stop_scraping, emails_found

    while url_queue and not stop_scraping:
        current_url, current_depth = url_queue.popleft()

        if current_url in visited_pages:
            continue
        if len(visited_pages) >= max_urls:
            stop_scraping = True
            break

        html = await fetch_page(session, current_url)
        visited_pages.add(current_url)

        if html is None:
            scrapped_pages[current_url] = 0
            continue

        page_emails, page_links = parse_page(html, current_url)
        emails_found.update(page_emails)
        scrapped_pages[current_url] = len(page_emails)

        # Batch logging
        if len(emails_found) % batchSize == 0:
            batch_num = len(emails_found) // batchSize
            print(f"📊 Progress Batch {batch_num} — {len(emails_found)} Emails scraped so far")

        # Add new links to queue
        if current_depth < depth:
            for link in page_links:
                if stay_in_domain:
                    if urlparse(link).netloc != urlparse(URL).netloc:
                        continue
                if link not in visited_pages:
                    url_queue.append((link, current_depth + 1))

# =========================
# Main async crawl
# =========================
async def main():
    url_queue.append((URL, 0))
    async with aiohttp.ClientSession() as session:
        workers = [worker(session, max_depth) for _ in range(max_concurrent_requests)]
        await asyncio.gather(*workers)

# =========================
# Save results safely
# =========================
def save_results():
    # Save emails
    with open(fileName, "w", encoding="utf-8") as f:
        json.dump({"emailAddresses": sorted(emails_found)}, f, indent=1)

    # Save scraped pages sorted by number of emails descending
    sorted_pages = dict(sorted(scrapped_pages.items(), key=lambda x: x[1], reverse=True))
    with open(scrapedPagesFile, "w", encoding="utf-8") as f:
        json.dump(sorted_pages, f, indent=2)

# =========================
# Run script
# =========================
if __name__ == "__main__":
    try:
        start_time = datetime.now()
        print(f"🔍 Starting scraping… Please wait 😎\n🕒 Start Time: {start_time.strftime('%d/%m/%Y %I:%M %p')}")
        asyncio.run(main())
    finally:
        end_time = datetime.now()
        total_time = end_time - start_time

        hours, remainder = divmod(total_time.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        print(f"🕒 End Time: {end_time.strftime('%d/%m/%Y %I:%M %p')}")
        print(f"⏳ Total Time Taken: {hours}H {minutes}M {seconds}S")

        print("💾 Saving all progress…")
        save_results()
        print(f"🎉 Scraping completed! Total pages visited: {len(visited_pages)}")
        print(f"📩 Total emails found: {len(emails_found)}")


