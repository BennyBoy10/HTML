import imaplib
import email
import json
import re
import sys
from email.header import decode_header
import time
from typing import List, Set

EMAIL = "folamiemmanuel18@gmail.com"
PASSWORD = "dfhd cwup hbas isgy"

class Colors:
    reset = '\x1b[0m'
    bright = '\x1b[1m'
    green = '\x1b[32m'
    yellow = '\x1b[33m'
    blue = '\x1b[34m'
    magenta = '\x1b[35m'
    cyan = '\x1b[36m'
    red = '\x1b[31m'
    white = '\x1b[37m'

class EmailScraper:
    def __init__(self, email_address: str, app_password: str):
        self.email_address = email_address
        self.app_password = app_password
        self.mail = None
        self.scraped_emails: Set[str] = set()
        self.total_emails = 0
        self.processed_count = 0
        self.new_emails_count = 0
        
    def log(self, message: str, color: str = Colors.white):
        """Simple logging without timestamps"""
        print(f"{color}{message}{Colors.reset}")

    def print_banner(self):
        """Print startup banner"""
        print(f"\n{Colors.bright}{Colors.cyan}{'='*50}{Colors.reset}")
        print(f"{Colors.bright}{Colors.cyan}        EMAIL INBOX SCRAPER{Colors.reset}")
        print(f"{Colors.bright}{Colors.cyan}{'='*50}{Colors.reset}")
        print(f"{Colors.yellow}Target: {Colors.white}{self.email_address}{Colors.reset}")
        print(f"{Colors.yellow}Output: {Colors.white}scrappedEmails.json{Colors.reset}")
        print(f"{Colors.bright}{Colors.cyan}{'='*50}{Colors.reset}\n")

    def connect_to_gmail(self) -> bool:
        """Connect to Gmail IMAP server"""
        try:
            self.log("🔌 Connecting to Gmail...", Colors.yellow)
            
            self.mail = imaplib.IMAP4_SSL("imap.gmail.com")
            self.log("✅ Connected to Gmail", Colors.green)
            
            self.log("🔐 Logging in...", Colors.yellow)
            self.mail.login(self.email_address, self.app_password)
            self.log("✅ Logged in successfully", Colors.green)
            
            return True
            
        except imaplib.IMAP4.error:
            self.log("❌ Login failed - check email/password", Colors.red)
            return False
        except Exception as e:
            self.log(f"❌ Connection error: {str(e)}", Colors.red)
            return False

    def get_total_emails(self) -> int:
        """Get total number of emails in inbox"""
        try:
            self.mail.select("inbox")
            status, messages = self.mail.search(None, "ALL")
            if status == "OK":
                email_ids = messages[0].split()
                total = len(email_ids)
                self.log(f"📧 Emails in inbox: {total}", Colors.cyan)
                return total
            return 0
        except Exception:
            self.log("❌ Error counting emails", Colors.red)
            return 0

    def extract_email_addresses_from_text(self, text: str) -> List[str]:
        """Extract email addresses from text"""
        email_patterns = [
            r'Email Address:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            r'<b>Email Address</b>:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            r'Email:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
        ]

        found_emails = []
        for pattern in email_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            found_emails.extend(matches)
        
        return found_emails

    def decode_mime_words(self, text):
        """Decode MIME encoded words"""
        if text is None:
            return ""
        decoded_parts = decode_header(text)
        decoded_text = ""
        for part, encoding in decoded_parts:
            if isinstance(part, bytes):
                if encoding:
                    decoded_text += part.decode(encoding)
                else:
                    decoded_text += part.decode('utf-8', errors='ignore')
            else:
                decoded_text += part
        return decoded_text

    def process_email(self, msg):
        """Process individual email and extract email addresses"""
        try:
            email_content = ""
            
            # Walk through email parts
            if msg.is_multipart():
                for part in msg.walk():
                    content_type = part.get_content_type()
                    content_disposition = str(part.get("Content-Disposition"))
                    
                    if content_type in ["text/plain", "text/html"] and "attachment" not in content_disposition:
                        try:
                            payload = part.get_payload(decode=True)
                            if payload:
                                email_content += payload.decode('utf-8', errors='ignore')
                        except:
                            pass
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    email_content = payload.decode('utf-8', errors='ignore')
            
            # Extract email addresses
            extracted_emails = self.extract_email_addresses_from_text(email_content)
            
            new_emails = []
            for email_addr in extracted_emails:
                if email_addr not in self.scraped_emails:
                    self.scraped_emails.add(email_addr)
                    new_emails.append(email_addr)
                    self.new_emails_count += 1
            
            # Log new emails found in this message
            for email_addr in new_emails:
                self.log(f"✅ Saved: {email_addr}", Colors.green)
            
            return len(new_emails)
            
        except Exception:
            return 0

    def show_progress(self):
        """Show progress in percentage and count"""
        percentage = (self.processed_count / self.total_emails) * 100
        self.log(f"📊 Progress: {self.processed_count}/{self.total_emails} ({percentage:.1f}%)", Colors.blue)

    def scrape_emails(self):
        """Main method to scrape emails from inbox"""
        try:
            if not self.connect_to_gmail():
                return False

            self.total_emails = self.get_total_emails()
            if self.total_emails == 0:
                self.log("⚠️ No emails found in inbox", Colors.yellow)
                return True

            self.log("🚀 Starting email scraping...", Colors.yellow)
            
            # Select inbox
            self.mail.select("inbox")
            
            # Search all emails
            status, messages = self.mail.search(None, "ALL")
            if status != "OK":
                self.log("❌ Failed to search emails", Colors.red)
                return False

            email_ids = messages[0].split()
            
            self.log(f"🔍 Processing {len(email_ids)} emails...", Colors.cyan)
            
            # Process emails
            for i, email_id in enumerate(email_ids):
                try:
                    # Fetch email
                    status, msg_data = self.mail.fetch(email_id, "(RFC822)")
                    if status != "OK":
                        continue
                        
                    # Parse email
                    msg = email.message_from_bytes(msg_data[0][1])
                    self.process_email(msg)
                    self.processed_count += 1
                    
                    # Show progress every 10% or 50 emails, whichever comes first
                    if self.processed_count % max(50, self.total_emails // 10) == 0:
                        self.show_progress()
                        
                except Exception:
                    continue
            
            self.log("🎉 Scraping completed!", Colors.green)
            self.log(f"📊 Total processed: {self.processed_count}", Colors.cyan)
            self.log(f"📧 Unique emails found: {len(self.scraped_emails)}", Colors.green)
            
            return True
            
        except Exception as e:
            self.log(f"❌ Scraping failed: {str(e)}", Colors.red)
            return False
        finally:
            self.close_connection()

    def save_emails_to_json(self):
        """Save scraped emails to JSON file"""
        try:
            emails_list = sorted(list(self.scraped_emails))
            
            with open('scrappedEmails.json', 'w', encoding='utf-8') as f:
                json.dump(emails_list, f, indent=2, ensure_ascii=False)
            
            self.log(f"💾 Saved {len(emails_list)} emails to scrappedEmails.json", Colors.green)
            return True
            
        except Exception as e:
            self.log(f"❌ Error saving JSON: {str(e)}", Colors.red)
            return False

    def close_connection(self):
        """Close IMAP connection"""
        try:
            if self.mail:
                self.mail.logout()
                self.log("🔒 Connection closed", Colors.green)
        except:
            pass

def main():
    # Configuration
    EMAIL_ADDRESS = EMAIL
    APP_PASSWORD = PASSWORD

    # Initialize scraper
    scraper = EmailScraper(EMAIL_ADDRESS, APP_PASSWORD)
    
    # Print banner
    scraper.print_banner()
    
    try:
        # Scrape emails
        success = scraper.scrape_emails()
        
        if success and scraper.scraped_emails:
            # Save to JSON
            scraper.save_emails_to_json()
            
            # Final summary
            print(f"\n{Colors.bright}{Colors.green}{'='*50}{Colors.reset}")
            print(f"{Colors.bright}{Colors.green}          COMPLETED SUCCESSFULLY{Colors.reset}")
            print(f"{Colors.bright}{Colors.green}{'='*50}{Colors.reset}")
            print(f"{Colors.cyan}📧 Unique emails: {Colors.white}{len(scraper.scraped_emails)}{Colors.reset}")
            print(f"{Colors.cyan}💾 Output: {Colors.white}scrappedEmails.json{Colors.reset}")
            print(f"{Colors.bright}{Colors.green}{'='*50}{Colors.reset}\n")
            
        elif not scraper.scraped_emails:
            scraper.log("⚠️ No email addresses found", Colors.yellow)
            
        else:
            scraper.log("❌ Scraping failed", Colors.red)
            
    except KeyboardInterrupt:
        scraper.log("⚠️ Script interrupted by user", Colors.yellow)
    except Exception as e:
        scraper.log(f"❌ Unexpected error: {str(e)}", Colors.red)

if __name__ == "__main__":
    main()




