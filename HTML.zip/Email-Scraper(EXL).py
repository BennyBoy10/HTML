import os
import re
import sys
import traceback
from datetime import datetime

from openpyxl import load_workbook

Single_File = True
PDF_DIR = os.path.join(os.getcwd(), "PDF")
OUTPUT_DIR = os.path.join(os.getcwd(), "JSON")
fileName = "Excel-Emails.txt"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, fileName)

colors = {
    "reset": '\x1b[0m',
    "bright": '\x1b[1m',
    "green": '\x1b[32m',
    "yellow": '\x1b[33m',
    "blue": '\x1b[34m',
    "magenta": '\x1b[35m',
    "cyan": '\x1b[36m',
    "red": '\x1b[31m',
    "white": '\x1b[37m'
}

# ====== UTILITIES ======
def print_log(message, color="reset"):
    print(f"{colors.get(color, colors['reset'])}{message}{colors['reset']}")

def extract_emails_from_text(text):
    # same improved regex as your PDF script
    pattern = r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}'
    return re.findall(pattern, text)

def ensure_dir(path):
    try:
        if not os.path.exists(path):
            os.makedirs(path)
            print_log(f"Created directory: {path}", "magenta")
    except Exception as e:
        print_log(f"Failed to create directory {path}: {e}", "red")
        sys.exit(1)


# ====== MAIN ======
def main():
    start_time = datetime.now()
    start_str = start_time.strftime("%d/%m/%Y %I:%M %p")
    print_log(f"Script started at: {start_str}", "bright")

    ensure_dir(PDF_DIR)
    ensure_dir(OUTPUT_DIR)

    try:
        excel_files = [f for f in os.listdir(PDF_DIR) if f.lower().endswith((".xlsx", ".xlsm", ".xltx", ".xltm"))]
        total_files = len(excel_files)
        if total_files == 0:
            print_log("No Excel files found in the PDF directory.", "yellow")
            return

        email_counter = 1
        all_emails = []
        total_emails_extracted = 0

        for idx, excel_file in enumerate(excel_files, 1):
            excel_path = os.path.join(PDF_DIR, excel_file)
            print_log(f"\nProcessing file {idx}/{total_files}: {excel_file}", "cyan")
            try:
                # load workbook in read-only mode to handle large files
                wb = load_workbook(excel_path, read_only=True, data_only=True)
            except Exception as e:
                print_log(f"Failed to open workbook {excel_file}: {e}", "red")
                traceback.print_exc()
                continue

            try:
                file_text_chunks = []
                for sheet_name in wb.sheetnames:
                    try:
                        ws = wb[sheet_name]
                        print_log(f"  Reading sheet: {sheet_name}", "blue")
                        # iterate through rows in read-only mode
                        for row in ws.iter_rows(values_only=True):
                            # join all cell values in the row into a single string
                            try:
                                row_text = " ".join("" if c is None else str(c) for c in row)
                                if row_text.strip():
                                    file_text_chunks.append(row_text)
                            except Exception:
                                # if converting a specific cell fails, proceed
                                continue
                    except Exception as e_sheet:
                        print_log(f"  Warning: Failed to read sheet {sheet_name} in {excel_file}: {e_sheet}", "yellow")
                        continue

                text_content = "\n".join(file_text_chunks)
                if not text_content.strip():
                    print_log(f"No text found in {excel_file}. Skipping.", "yellow")
                    continue

                emails = extract_emails_from_text(text_content)
                # dedupe while preserving order
                seen = set()
                unique_emails = []
                for em in emails:
                    if em not in seen:
                        seen.add(em)
                        unique_emails.append(em)

                num_emails = len(unique_emails)
                if num_emails == 0:
                    print_log(f"No emails found in {excel_file}.", "red")
                else:
                    total_emails_extracted += num_emails
                    log_colors = ["magenta"]
                    color = log_colors[idx % len(log_colors)]
                    print_log(f"Extracted {num_emails} emails from {excel_file}", color)

                    if Single_File:
                        all_emails.extend(unique_emails)
                    else:
                        out_file = os.path.join(OUTPUT_DIR, f"emails{email_counter}.txt")
                        try:
                            with open(out_file, "w", encoding="utf-8") as f:
                                f.write("\n".join(unique_emails))
                            color = log_colors[email_counter % len(log_colors)]
                            print_log(f"Saved {num_emails} emails to {out_file}", color)
                        except Exception as e_write:
                            print_log(f"Failed to save {out_file}: {e_write}", "red")
                        email_counter += 1

            except Exception as e_processing:
                print_log(f"Failed processing {excel_file}: {e_processing}", "red")
                traceback.print_exc()
            finally:
                try:
                    wb.close()
                except Exception:
                    pass

        # Save all emails if Single_File mode
        if Single_File and all_emails:
            try:
                # dedupe overall and preserve order
                seen = set()
                deduped = []
                for em in all_emails:
                    if em not in seen:
                        seen.add(em)
                        deduped.append(em)
                with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
                    f.write("\n".join(deduped))
                print_log(f"\nAll emails saved to {OUTPUT_FILE}", "green")
            except Exception as e:
                print_log(f"Failed to save emails to {OUTPUT_FILE}: {e}", "red")

        # Summary
        print_log(f"\nSummary: Extracted {total_emails_extracted} emails.", "bright")
        print_log(f"\nSaved {total_emails_extracted} Emails to: {fileName}", "bright")

        end_time = datetime.now()
        end_str = end_time.strftime("%d/%m/%Y %I:%M %p")
        duration = end_time - start_time
        h, remainder = divmod(duration.total_seconds(), 3600)
        m, s = divmod(remainder, 60)
        print_log(f"Script ended at: {end_str}", "bright")
        print_log(f"Time used: {int(h):02d}_{int(m):02d}_{int(s):02d}", "bright")

        print_log("\nProcessing complete!", "green")

    except Exception as e:
        print_log(f"Unexpected error: {e}", "red")
        traceback.print_exc()


if __name__ == "__main__":
    main()




