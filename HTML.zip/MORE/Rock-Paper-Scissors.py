
import random
import sys

print("""Welcome to the Rock Paper Scissors Game!

Rules:
- Rock beats Scissors
- Scissors beats Paper
- Paper beats Rock

Let's see if you can beat the computer! 

To play, type 'rock', 'paper', or 'scissors' when prompted. 

Good luck and have fun!
""")

def scores():
    global player, computer
    player = 0
    computer = 0
scores()


the3 = ["rock", "paper", "scissors"]

def com_choice():
    return random.choice(the3)



def results():
    print("\n***************************")
    print(f"Player: {player_choice.capitalize()}.")
    print(f"Computer: {computer_choice.capitalize()}.")
    print(f"You: {player}")
    print(f"Computer: {computer}\n")  



while True:
    player_choice = input("Choose one; Rock, Paper, Scissors: ").strip().lower()
    computer_choice = com_choice()

    if (player_choice == "rock") and (computer_choice == "rock"):
        player += 1
        computer += 1
        results()
        print("This round is a draw!")
        print("***************************")

    elif (player_choice == "rock") and (computer_choice == "paper"):
        player += 0
        computer += 1
        results()
        print("The computer won this round!")
        print("***************************")

    elif (player_choice == "rock") and (computer_choice == "scissors"):
        player += 1
        computer += 0
        results()
        print("You won this round!")
        print("***************************")

    elif (player_choice == "paper") and (computer_choice == "rock"):
        player += 1
        computer += 0
        results()
        print("You won this round!")
        print("***************************")

    elif (player_choice == "paper") and (computer_choice == "paper"):
        player += 1
        computer += 1
        results()
        print("This round is a draw!")
        print("***************************")

    elif (player_choice == "paper") and (computer_choice == "scissors"):
        player += 0
        computer += 1
        results()
        print("The computer won this round!")
        print("***************************")

    elif (player_choice == "scissors") and (computer_choice == "rock"):
        player += 0
        computer += 1
        results()
        print("The computer won this round!")
        print("***************************")

    elif (player_choice == "scissors") and (computer_choice == "paper"):
        player += 1
        computer += 0
        results()
        print("You won this round!")
        print("***************************")

    elif (player_choice == "scissors") and (computer_choice == "scissors"):
        player += 1
        computer += 1
        results()
        print("This round is a draw!")
        print("***************************")

    else:
        print("Invalid input. Choose (Rock, Paper, Scissors).")













