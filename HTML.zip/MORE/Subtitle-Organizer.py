
import os

directory = "."
subtitle_files = []
count = 0

def organize():
    global subtitle_files, count
    for filename in os.listdir(directory):
        if filename.endswith(".srt"):
            subtitle_files.append(filename)
            count += 1
    for file in subtitle_files:
        os.rename(file, os.path.join("Subtitles", file))
    print(f"Moved a total of {count} files to Subtitles")

# Create the Subtitles directory if it doesn't exist
if not os.path.exists("Subtitles"):
    os.makedirs("Subtitles")

organize()





