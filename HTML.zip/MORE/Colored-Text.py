
from colorama import Fore

print(f"{Fore.RED}BennyBoy")
print(f"{Fore.BLUE}BennyBoy")









