
import os, shutil, sys

def organize():
    print("Organize")
    directory = os.getcwd()
    gif_files = []
    mp4_files = []
    triple_x_files = []
    webm_files = []

    gif_count = 0
    mp4_count = 0
    triple_x_count = 0
    webm_count = 0

    for filename in os.listdir(directory):
        if filename.lower().endswith(".gif"):
            gif_files.append(filename)
        elif filename.lower().startswith("ssstwitter"):
            triple_x_files.append(filename)
        elif filename.lower().endswith(".mp4"):
            mp4_files.append(filename)
        elif filename.lower().endswith(".webm"):
            webm_files.append(filename)
        else:
            pass

    # Create folders only if there are files to move
    if gif_files:
        os.makedirs("Gifs", exist_ok=True)
        print("Created Gif folder!")
        for file in gif_files:
            shutil.move(file, "Gifs")
            gif_count += 1

    if triple_x_files:
        os.makedirs("Triple-X", exist_ok=True)
        print("Created Triple-X folder!")
        for file in triple_x_files:
            shutil.move(file, "Triple-X")
            triple_x_count += 1

    if mp4_files:
        os.makedirs("Videos", exist_ok=True)
        print("Created Videos folder!")
        for file in mp4_files:
            shutil.move(file, "Videos")
            mp4_count += 1

    if webm_files:
        os.makedirs("Webm", exist_ok=True)
        print("Created Webm folder!")
        for file in webm_files:
            shutil.move(file, "Webm")
            webm_count += 1

    # Print the number of files moved
    print(f"Moved a total of {gif_count} Gif files.")
    print(f"Moved a total of {triple_x_count} Triple-X files.")
    print(f"Moved a total of {mp4_count} MP4 files.")
    print(f"Moved a total of {webm_count} Webm files.")

organize()

# Ask user to close the script
#which = input("Enter 0 to close: ")
#if which == '0':
#    sys.exit()









