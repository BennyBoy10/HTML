import os
import re

# Folder path
folder_path = "Anime"  # Adjust the folder path if needed

# Initialize a counter
renamed_count = 0

print("Starting...")

# Get all files in the folder
for file_name in os.listdir(folder_path):
    # Match filenames with the pattern "Epìsode - <number>.mkv"
    #match = re.match(r"Epìsode - (\d+)\.mkv", file_name)
    match = re.match(r"One Piece \(Dub\) - (\d+).*\.mkv", file_name)

    if match:
        # Extract the episode number
        episode_number = match.group(1)
        # Create the new filename
        new_name = f"EP.{episode_number}.mkv"
        # Rename the file
        os.rename(
            os.path.join(folder_path, file_name),
            os.path.join(folder_path, new_name)
        )
        renamed_count += 1  # Increment the counter
        print(f'Renamed: "{file_name}" to "{new_name}"')

print(f"Renamed a total of {renamed_count} episodes!")
print("Renaming complete!")

#One Piece (Dub) - 575 720p.mkv
