import random

# Generate a 25-digit random number
random_number = ''.join(str(random.randint(0, 9)) for _ in range(25))

print(random_number)



