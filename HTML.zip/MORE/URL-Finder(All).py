
# Get all URL's from a webpage'

import requests
from bs4 import BeautifulSoup

def get_all_urls(url):
    try:
        # Fetch the content of the website
        response = requests.get(url)
        response.raise_for_status()  # Check for request errors

        # Parse the HTML content
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find all links
        links = soup.find_all('a', href=True)
        urls = set()  # Use a set to avoid duplicate URLs

        for link in links:
            href = link.get('href')
            if href.startswith('http'):
                urls.add(href)
            else:
                # Handle relative URLs
                urls.add(requests.compat.urljoin(url, href))

        return urls

    except requests.exceptions.RequestException as e:
        print(f"Error fetching {url}: {e}")
        return set()

def main():
    website_url = "https://bulamabenjamin.website"
    #website_url = input("Enter the website URL: ")
    urls = get_all_urls(website_url)

    # Sort the URLs in alphabetical order
    print("Sorting URLs in alphabetical order...")
    sorted_urls = sorted(urls)
    print("Writing in alphabetical order... Done.")

    # Write the URLs to a file with numbering
    with open('urls.txt', 'w') as file:
        print("Numbering URLs...")
        for i, url in enumerate(sorted_urls, start=1):
            file.write(f"{i}. {url}\n")
        print("Numbering... Done.")

    print(f"Successfully found {len(urls)} URLs. They have been written to urls.txt.")

main()




