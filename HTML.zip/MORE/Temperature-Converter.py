
def celcus():
    temp = round((number - 32) * 5 / 9, 1)    
    print(f"{number}°F in Celcus is {temp}°C.\n")
#celcus()

def fahrenheit():
    temp = round((9 * number) / 5 + 33, 1)
    print(f"{number}°C in Fahrenheit is {temp}°F.\n")
#fahrenheit()


print("Temperature Converter🌡️\n")

while True:
    try:
        number = float(input("Enter a number: "))
        convert = input("Convert to (C/F): "). strip().lower()

        if convert == "c":
            celcus()
        elif convert == "f":
            fahrenheit()
        else:
            print(f"{convert} is not a valid unit!")

    except ValueError:
        print("Invalid input!")



