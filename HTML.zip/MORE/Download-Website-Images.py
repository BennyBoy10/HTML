import requests
from bs4 import BeautifulSoup
import os
from urllib.parse import urljoin, urlparse

# The URL of the website you want to scrape
url = "https://bulamabenjamin.carrd.co"



print(f"Visiting {url}")

try:
    # Send a request to the webpage
    response = requests.get(url)
    response.raise_for_status()  # Check if the request was successful
except requests.exceptions.RequestException as e:
    print(f"Internet Connection error: {e}")
    exit()  # Exit if there is a connection issue

print("Downloading Images...")

# Parse the webpage content
soup = BeautifulSoup(response.text, "html.parser")

# Find all image tags
images = soup.find_all("img")

if not images:
    print("No images found.")
    exit()  # Exit if no images are found

# Create a folder to store the images
os.makedirs("Images", exist_ok=True)

# Counter for downloaded images
count = 0

# Loop through all image tags and download the images
for img in images:
    img_url = img.get("src")
    
    # Convert relative URLs to absolute URLs
    img_url = urljoin(url, img_url)
    
    # Clean up the image name
    img_name = os.path.basename(urlparse(img_url).path)
    
    try:
        # Fetch and save the image
        img_data = requests.get(img_url).content
        img_name = os.path.join("Images", img_name)
        with open(img_name, "wb") as handler:
            handler.write(img_data)
        count += 1  # Increment the counter for each downloaded image
        print(f"Downloaded: {img_name}")
    except Exception as e:
        print(f"Failed to download {img_url}: {e}")

# Final step
if count > 0:
    print(f"Download completed! {count} images downloaded.")
else:
    print("No images downloaded.")






