
# Byte to KB/MB/GB converter!

print("Byte to KB/MB/GB\n")

def convert_bytes(byte_size):
    """Convert bytes to KB, MB, or GB based on the size."""
    if byte_size < 1024:
        return f"{byte_size} Bytes"
    elif byte_size < 1024**2:
        return f"{byte_size / 1024:.2f} KB"
    elif byte_size < 1024**3:
        return f"{byte_size / 1024**2:.2f} MB"
    else:
        return f"{byte_size / 1024**3:.2f} GB"

def main():
    try:
        byte_input = int(input("\nEnter the size in bytes: "))
        if byte_input < 0:
            print("Enter a number: ")
        else:
            converted_value = convert_bytes(byte_input)
            print(f"Converted Value: {converted_value}")
    except ValueError:
        print("Invalid input. Please enter a valid integer.")

if __name__ == "__main__":
    while True:
        main()





