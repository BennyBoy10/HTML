
import os
import shutil

def organize_files():
    # Current directory
    directory = os.getcwd()
    
    # Define the folder names and file extensions
    folders = {
        'Videos': ['.mp4', '.mkv', '.webp'],
        'Images': ['.jpg', '.jpeg', '.png', '.gif'],
        'Apps': ['.apk', '.exe', '.msi'],
        'Music': ['.mp3'],
        'Documents': []  # Default folder for other file types
    }

    # Initialize counters for each file type
    counters = {
        'Videos': 0,
        'Anime': 0,
        'Images': 0,
        'Apps': 0,
        'Music': 0,
        'Documents': 0
    }

    # Define a function to move files to their respective folders
    def move_file(file_path, target_folder):
        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        shutil.move(file_path, target_folder)

    # Iterate through the files in the given directory
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        
        if os.path.isfile(item_path):
            file_ext = os.path.splitext(item)[1].lower()

            # Handle Videos and Anime subfolder
            if file_ext in folders['Videos']:
                if item.startswith('EP') and item.endswith('.mp4'):
                    move_file(item_path, os.path.join(directory, 'Videos', 'Anime'))
                    counters['Anime'] += 1
                else:
                    move_file(item_path, os.path.join(directory, 'Videos'))
                    counters['Videos'] += 1

            # Handle Images
            elif file_ext in folders['Images']:
                move_file(item_path, os.path.join(directory, 'Images'))
                counters['Images'] += 1

            # Handle Apps
            elif file_ext in folders['Apps']:
                move_file(item_path, os.path.join(directory, 'Apps'))
                counters['Apps'] += 1

            # Handle Music
            elif file_ext in folders['Music']:
                move_file(item_path, os.path.join(directory, 'Music'))
                counters['Music'] += 1

            # Handle Documents for other file types
            else:
                move_file(item_path, os.path.join(directory, 'Documents'))
                counters['Documents'] += 1

        # Ignore existing folders in the directory
        elif os.path.isdir(item_path):
            continue

    # Print results
    print(f"Moved {counters['Videos']} video files to Videos.")
    print(f"Moved {counters['Anime']} anime files to Videos/Anime.")
    print(f"Moved {counters['Images']} image files to Images.")
    print(f"Moved {counters['Apps']} application files to Apps.")
    print(f"Moved {counters['Music']} music files to Music.")
    print(f"Moved {counters['Documents']} files to Documents.")

if __name__ == "__main__":
    organize_files()
    print("Files have been organized.")





