# Email-Organizer(TXT-JSON).py

import os
import sys
import json
import tempfile

INPUT_PATH = os.path.join("JSON", "emails.txt")
OUTPUT_PATH = os.path.join("JSON", "emails.json")
JSON_KEY = "emailAddresses"
LOWERCASE_ALL = False

colors = {
    "reset": '\x1b[0m',
    "bright": '\x1b[1m',
    "green": '\x1b[32m',
    "yellow": '\x1b[33m',
    "blue": '\x1b[34m',
    "magenta": '\x1b[35m',
    "cyan": '\x1b[36m',
    "red": '\x1b[31m',
    "white": '\x1b[37m'
}

#  HELPERS
def safe_open(path, mode, encodings=("utf-8", "utf-8-sig", "latin-1")):
    """Try opening a file with multiple encodings"""
    last_exc = None
    for enc in encodings:
        try:
            return open(path, mode, encoding=enc)
        except Exception as e:
            last_exc = e
    raise last_exc

def ensure_dir_exists(path):
    d = os.path.dirname(path)
    if d and not os.path.exists(d):
        try:
            os.makedirs(d, exist_ok=True)
            print(f"{colors['green']}✅ Created folder: {d}{colors['reset']}")
        except Exception as e:
            print(f"{colors['red']}❌ Failed to create folder {d}: {e}{colors['reset']}")
            raise

def write_json_atomic(path, data):
    """Write JSON safely using a temp file"""
    ensure_dir_exists(path)
    tmp_fd, tmp_path = tempfile.mkstemp(prefix="._tmp_emails_", dir=os.path.dirname(path) or ".")
    os.close(tmp_fd)
    try:
        with open(tmp_path, "w", encoding="utf-8") as tf:
            json.dump(data, tf, indent=1, ensure_ascii=False)
        os.replace(tmp_path, path)
        print(f"{colors['green']}✅ Wrote output to: {path}{colors['reset']}")
    except Exception as e:
        print(f"{colors['red']}❌ Failed to write output: {e}{colors['reset']}")
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise

# ------------------ PROCESSING -------------------
def process_emails(lines):
    """Clean lines, remove duplicates, sort, optionally lowercase"""
    total = len(lines)
    print(f"{colors['cyan']}🔵 Starting email processing || {INPUT_PATH} || Total lines: {total}{colors['reset']}")

    if total == 0:
        print(f"{colors['yellow']}⚠️  No lines found. Exiting.{colors['reset']}")
        return [], 0, []

    cleaned = []
    errors = []
    seen = set()
    percent_step = 10
    next_percent = percent_step
    processed = 0

    for idx, line in enumerate(lines, start=1):
        try:
            email = line.strip()
            if not email:
                processed += 1
                pct = (processed / total) * 100
                while pct >= next_percent and next_percent <= 100:
                    print(f"{colors['yellow']}{int(next_percent)}% Done{colors['reset']}")
                    next_percent += percent_step
                continue

            if LOWERCASE_ALL:
                email_norm = email.lower()
            else:
                email_norm = email

            if email_norm not in seen:
                seen.add(email_norm)
                cleaned.append(email_norm)

            processed += 1
            pct = (processed / total) * 100
            while pct >= next_percent and next_percent <= 100:
                print(f"{colors['yellow']}{int(next_percent)}% Done{colors['reset']}")
                next_percent += percent_step

        except Exception as e:
            errors.append((idx, line, str(e)))
            processed += 1
            pct = (processed / total) * 100
            while pct >= next_percent and next_percent <= 100:
                print(f"{colors['yellow']}{int(next_percent)}% Done{colors['reset']}")
                next_percent += percent_step

    if next_percent <= 100:
        for p in range(int(next_percent), 101, percent_step):
            print(f"{colors['yellow']}{p}% Done{colors['reset']}")

    try:
        final = sorted(cleaned)
    except Exception as e:
        print(f"{colors['red']}❌ Sorting failed: {e} — returning unsorted unique list{colors['reset']}")
        final = list(cleaned)

    return final, total, errors

# --------------------- MAIN -----------------------
def main():
    try:
        ensure_dir_exists(INPUT_PATH)
        with safe_open(INPUT_PATH, "r") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"{colors['red']}❌ Failed to read {INPUT_PATH}: {e}{colors['reset']}")
        return

    final_list, total_lines, errors = process_emails(lines)

    payload = {JSON_KEY: final_list}

    try:
        write_json_atomic(OUTPUT_PATH, payload)
    except Exception as e:
        print(f"{colors['red']}❌ Failed to write JSON: {e}{colors['reset']}")
        return

    success_count = len(final_list)
    duplicates_removed = total_lines - success_count

    print(f"{colors['blue']}{'='*40}{colors['reset']}")
    print(f"{colors['magenta']}{colors['bright']}📋 SUMMARY{colors['reset']}")
    print(f"{colors['blue']}{'='*40}{colors['reset']}")
    print(f"{colors['green']}✅ Emails saved: {success_count}{colors['reset']}")
    print(f"{colors['yellow']}⚠️  Duplicates removed: {duplicates_removed}{colors['reset']}")
    print(f"{colors['white']}📄 Total lines read: {total_lines}{colors['reset']}")
    if errors:
        print(f"{colors['red']}❌ Errors encountered: {len(errors)}{colors['reset']}")
        for idx, line, msg in errors[:10]:
            print(f"{colors['red']}- Line {idx}: {msg} (preview: {line.strip()[:50]!r}){colors['reset']}")
        if len(errors) > 10:
            print(f"{colors['red']}- ...and {len(errors)-10} more errors{colors['reset']}")
    else:
        print(f"{colors['green']}🎉 No processing errors encountered{colors['reset']}")

    print(f"{colors['cyan']}💾 JSON saved to: {OUTPUT_PATH}{colors['reset']}")

# -------------------- RUN ------------------------
if __name__ == "__main__":
    try:
        main()
    except Exception as fatal:
        print(f"{colors['red']}❌ Fatal error: {fatal}{colors['reset']}")
        sys.exit(1)

