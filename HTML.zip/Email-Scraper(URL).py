import requests
import re
import json
from bs4 import BeautifulSoup

URL = "https://www.nhia.gov.ng/zonal-and-state-offices-2/"
fileName = "JSON/URL-Emails.json"

# Strict valid email pattern
EMAIL_FULL_RE = re.compile(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,24}$', re.I)
EMAIL_FIND_RE = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,24}', re.I)


def clean_email(raw: str):
    """Cleans junk like numbers/words stuck to the email."""
    s = raw.strip(" <>[]()'\":;,")
    if EMAIL_FULL_RE.fullmatch(s):
        return s

    # Trim trailing junk
    clean = s
    while clean and not EMAIL_FULL_RE.fullmatch(clean):
        if '@' not in clean:
            return None
        clean = clean[:-1].rstrip(" .,:;-_")

    return clean if EMAIL_FULL_RE.fullmatch(clean) else None


def scrape_emails(url):
    try:
        r = requests.get(url, timeout=12, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
    except Exception as e:
        print("❌ Error fetching page:", e)
        return []

    soup = BeautifulSoup(r.text, "html.parser")

    found = set()

    # From mailto links
    for a in soup.select('a[href^="mailto:"]'):
        raw = a['href'].split(":", 1)[1].split("?", 1)[0]
        cleaned = clean_email(raw)
        if cleaned:
            found.add(cleaned)

    # From href in general
    for a in soup.find_all(href=True):
        for match in EMAIL_FIND_RE.findall(a['href']):
            cleaned = clean_email(match)
            if cleaned:
                found.add(cleaned)

    # From visible text
    text = soup.get_text(" ")
    for match in EMAIL_FIND_RE.findall(text):
        cleaned = clean_email(match)
        if cleaned:
            found.add(cleaned)

    return sorted(found)


if __name__ == "__main__":
    print("🔍 Scraping emails… Please wait 😎")

    emails = scrape_emails(URL)

    if not emails:
        print("😢 No valid emails found!")
        exit()

    # Save file
    outFile = fileName
    with open(outFile, "w", encoding="utf-8") as f:
        json.dump({"emailAddresses": emails}, f, indent=1)

    # Summary
    print("🎉 DONE!")
    print(f"📩 Emails found: {len(emails)}")
    print(f"💾 Saved to: {outFile}")
    print("🚀 Script completed successfully!")
