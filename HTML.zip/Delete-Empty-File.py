import os

directory = "."

for filename in os.listdir(directory):
    file_path = os.path.join(directory, filename)
    if os.path.isfile(file_path) and os.path.getsize(file_path) <= 0:
        os.remove(file_path)
        print(f"Deleted: {filename}")




