#!/data/data/com.termux/files/usr/bin/bash
#!/bin/bash

echo ""
echo -e "\e[32mStarting... \e[0m"
echo ""

git add .
git commit -m "Update Python"
git push origin main

echo ""
echo -e "\e[32mDone!! \e[0m"
echo ""
