import imaplib
import email
import json
import re
import sys
from email.header import decode_header
import time
from typing import List, Set

EMAIL = "victoriabaker019@gmail.com"
PASSWORD = "ahom hphy fdus ovbu"

class Colors:
    reset = '\x1b[0m'
    bright = '\x1b[1m'
    green = '\x1b[32m'
    yellow = '\x1b[33m'
    blue = '\x1b[34m'
    magenta = '\x1b[35m'
    cyan = '\x1b[36m'
    red = '\x1b[31m'
    white = '\x1b[37m'

class UsernameScraper:
    def __init__(self, email_address: str, app_password: str):
        self.email_address = email_address
        self.app_password = app_password
        self.mail = None
        self.scraped_usernames: Set[str] = set()
        self.total_emails = 0
        self.processed_count = 0
        self.new_usernames_count = 0
        
    def log(self, message: str, color: str = Colors.white):
        """Simple logging without timestamps"""
        print(f"{color}{message}{Colors.reset}")

    def print_banner(self):
        """Print startup banner"""
        print(f"\n{Colors.bright}{Colors.cyan}{'='*50}{Colors.reset}")
        print(f"{Colors.bright}{Colors.cyan}        USERNAME SCRAPER (EMAILS ONLY){Colors.reset}")
        print(f"{Colors.bright}{Colors.cyan}{'='*50}{Colors.reset}")
        print(f"{Colors.yellow}Target: {Colors.white}{self.email_address}{Colors.reset}")
        print(f"{Colors.yellow}Looking for: {Colors.white}Username: (email addresses only){Colors.reset}")
        print(f"{Colors.yellow}Output: {Colors.white}scrappedEmails(Vicky).json{Colors.reset}")
        print(f"{Colors.bright}{Colors.cyan}{'='*50}{Colors.reset}\n")

    def connect_to_gmail(self) -> bool:
        """Connect to Gmail IMAP server"""
        try:
            self.log("🔌 Connecting to Gmail...", Colors.yellow)
            
            self.mail = imaplib.IMAP4_SSL("imap.gmail.com")
            self.log("✅ Connected to Gmail", Colors.green)
            
            self.log("🔐 Logging in...", Colors.yellow)
            self.mail.login(self.email_address, self.app_password)
            self.log("✅ Logged in successfully", Colors.green)
            
            return True
            
        except imaplib.IMAP4.error:
            self.log("❌ Login failed - check email/password", Colors.red)
            return False
        except Exception as e:
            self.log(f"❌ Connection error: {str(e)}", Colors.red)
            return False

    def get_total_emails(self) -> int:
        """Get total number of emails in inbox"""
        try:
            self.mail.select("inbox")
            status, messages = self.mail.search(None, "ALL")
            if status == "OK":
                email_ids = messages[0].split()
                total = len(email_ids)
                self.log(f"📧 Emails in inbox: {total}", Colors.cyan)
                return total
            return 0
        except Exception:
            self.log("❌ Error counting emails", Colors.red)
            return 0

    def is_valid_email(self, text: str) -> bool:
        """Check if text is a valid email address and not a phone number"""
        # Email regex pattern
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        # Phone number patterns to exclude
        phone_patterns = [
            r'^\d{10,15}$',  # 10-15 digits
            r'^\+\d{10,15}$',  # + followed by 10-15 digits
            r'^\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$',  # US format: 123-456-7890
            r'^\d{4}[-.\s]?\d{3}[-.\s]?\d{4}$',  # International format
        ]
        
        # Check if it's a phone number first
        for pattern in phone_patterns:
            if re.match(pattern, text.strip()):
                return False
        
        # Check if it's a valid email
        return bool(re.match(email_pattern, text.strip()))

    def extract_usernames_from_text(self, text: str) -> List[str]:
        """Extract email addresses from Username fields with various formats"""
        username_patterns = [
            # HTML format with bold tags (your template)
            r'<b>Username</b>\s*:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            r'Username\s*:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            r'username\s*:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            r'USERNAME\s*:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            
            # More flexible patterns that capture email after "Username:"
            r'Username[^:]*:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            r'<b>Username</b>[^:]*:\s*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})',
            
            # Broader pattern to catch any email after Username label
            r'Username[^:]*:\s*([^\s<>&]+@[^\s<>&]+\.[^\s<>&]+)',
            r'<b>Username</b>[^:]*:\s*([^\s<>&]+@[^\s<>&]+\.[^\s<>&]+)',
        ]

        found_usernames = []
        
        # Try all patterns
        for pattern in username_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                if self.is_valid_email(match):
                    found_usernames.append(match.lower().strip())
                else:
                    self.log(f"❌ Skipped (invalid email): {match}", Colors.yellow)
        
        # Remove duplicates while preserving order
        unique_usernames = []
        seen = set()
        for username in found_usernames:
            if username not in seen:
                seen.add(username)
                unique_usernames.append(username)
        
        return unique_usernames

    def decode_mime_words(self, text):
        """Decode MIME encoded words"""
        if text is None:
            return ""
        decoded_parts = decode_header(text)
        decoded_text = ""
        for part, encoding in decoded_parts:
            if isinstance(part, bytes):
                if encoding:
                    decoded_text += part.decode(encoding)
                else:
                    decoded_text += part.decode('utf-8', errors='ignore')
            else:
                decoded_text += part
        return decoded_text

    def process_email(self, msg):
        """Process individual email and extract usernames (email addresses only)"""
        try:
            email_content = ""
            
            # Walk through email parts
            if msg.is_multipart():
                for part in msg.walk():
                    content_type = part.get_content_type()
                    content_disposition = str(part.get("Content-Disposition"))
                    
                    if content_type in ["text/plain", "text/html"] and "attachment" not in content_disposition:
                        try:
                            payload = part.get_payload(decode=True)
                            if payload:
                                email_content += payload.decode('utf-8', errors='ignore')
                        except:
                            pass
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    email_content = payload.decode('utf-8', errors='ignore')

            # Extract usernames (email addresses only)
            extracted_usernames = self.extract_usernames_from_text(email_content)
            
            new_usernames = []
            for username in extracted_usernames:
                if username not in self.scraped_usernames:
                    self.scraped_usernames.add(username)
                    new_usernames.append(username)
                    self.new_usernames_count += 1
            
            # Log new usernames found in this message
            for username in new_usernames:
                self.log(f"✅ Saved: {username}", Colors.green)
            
            return len(new_usernames)
            
        except Exception as e:
            self.log(f"❌ Error processing email: {str(e)}", Colors.red)
            return 0

    def show_progress(self):
        """Show progress in percentage and count"""
        if self.total_emails > 0:
            percentage = (self.processed_count / self.total_emails) * 100
            self.log(f"📊 Progress: {self.processed_count}/{self.total_emails} ({percentage:.1f}%) | Usernames: {len(self.scraped_usernames)}", Colors.blue)
        else:
            self.log(f"📊 Processed: {self.processed_count} | Usernames: {len(self.scraped_usernames)}", Colors.blue)

    def scrape_usernames(self):
        """Main method to scrape usernames from inbox"""
        try:
            if not self.connect_to_gmail():
                return False

            self.total_emails = self.get_total_emails()
            if self.total_emails == 0:
                self.log("⚠️ No emails found in inbox", Colors.yellow)
                return True

            self.log("🚀 Starting username scraping...", Colors.yellow)
            self.log("🔍 Looking for 'Username:' fields containing email addresses...", Colors.cyan)
            
            # Select inbox
            self.mail.select("inbox")
            
            # Search all emails
            status, messages = self.mail.search(None, "ALL")
            if status != "OK":
                self.log("❌ Failed to search emails", Colors.red)
                return False

            email_ids = messages[0].split()
            
            self.log(f"🔍 Processing {len(email_ids)} emails...", Colors.cyan)
            
            # Process emails
            for i, email_id in enumerate(email_ids):
                try:
                    # Fetch email
                    status, msg_data = self.mail.fetch(email_id, "(RFC822)")
                    if status != "OK":
                        continue
                        
                    # Parse email
                    msg = email.message_from_bytes(msg_data[0][1])
                    new_count = self.process_email(msg)
                    self.processed_count += 1
                    
                    # Show progress every 10% or 50 emails, whichever comes first
                    progress_interval = max(50, self.total_emails // 10)
                    if progress_interval > 0 and self.processed_count % progress_interval == 0:
                        self.show_progress()
                        
                except Exception as e:
                    self.log(f"❌ Error processing email ID {email_id}: {str(e)}", Colors.red)
                    continue
            
            self.log("🎉 Scraping completed!", Colors.green)
            self.log(f"📊 Total emails processed: {self.processed_count}", Colors.cyan)
            self.log(f"📧 Unique usernames (emails) found: {len(self.scraped_usernames)}", Colors.green)
            
            return True
            
        except Exception as e:
            self.log(f"❌ Scraping failed: {str(e)}", Colors.red)
            return False
        finally:
            self.close_connection()

    def save_usernames_to_json(self):
        """Save scraped usernames to JSON file"""
        try:
            usernames_list = sorted(list(self.scraped_usernames))
            
            with open('scrappedEmails(Vicky).json', 'w', encoding='utf-8') as f:
                json.dump(usernames_list, f, indent=2, ensure_ascii=False)
            
            self.log(f"💾 Saved {len(usernames_list)} usernames to scrappedEmails(Vicky).json", Colors.green)
            return True
            
        except Exception as e:
            self.log(f"❌ Error saving JSON: {str(e)}", Colors.red)
            return False

    def close_connection(self):
        """Close IMAP connection"""
        try:
            if self.mail:
                self.mail.logout()
                self.log("🔒 Connection closed", Colors.green)
        except:
            pass

def main():
    # Configuration
    EMAIL_ADDRESS = EMAIL
    APP_PASSWORD = PASSWORD

    # Initialize scraper
    scraper = UsernameScraper(EMAIL_ADDRESS, APP_PASSWORD)
    
    # Print banner
    scraper.print_banner()
    
    try:
        # Scrape usernames
        success = scraper.scrape_usernames()
        
        if success and scraper.scraped_usernames:
            # Save to JSON
            scraper.save_usernames_to_json()
            
            # Final summary
            print(f"\n{Colors.bright}{Colors.green}{'='*50}{Colors.reset}")
            print(f"{Colors.bright}{Colors.green}          COMPLETED SUCCESSFULLY{Colors.reset}")
            print(f"{Colors.bright}{Colors.green}{'='*50}{Colors.reset}")
            print(f"{Colors.cyan}📧 Unique usernames (emails): {Colors.white}{len(scraper.scraped_usernames)}{Colors.reset}")
            print(f"{Colors.cyan}📊 Emails processed: {Colors.white}{scraper.processed_count}{Colors.reset}")
            print(f"{Colors.cyan}💾 Output: {Colors.white}scrappedEmails(Vicky).json{Colors.reset}")
            print(f"{Colors.bright}{Colors.green}{'='*50}{Colors.reset}\n")
            
        elif not scraper.scraped_usernames:
            scraper.log("⚠️ No valid usernames (email addresses) found", Colors.yellow)
            
        else:
            scraper.log("❌ Scraping failed", Colors.red)
            
    except KeyboardInterrupt:
        scraper.log("⚠️ Script interrupted by user", Colors.yellow)
        if scraper.scraped_usernames:
            scraper.log("💾 Saving current progress before exit...", Colors.yellow)
            scraper.save_usernames_to_json()
    except Exception as e:
        scraper.log(f"❌ Unexpected error: {str(e)}", Colors.red)

if __name__ == "__main__":
    main()



