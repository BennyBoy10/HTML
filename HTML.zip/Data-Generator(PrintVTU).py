def generate_data_plans():

    NETWORK_PRICES = {
        'MTN': 300,
        'Airtel': 280,
        'Glo': 270,
        '9Mobile': 260
    }

    DATA_SIZES = [1, 2, 3, 5, 7, 10, 15, 20, 25, 30]

    VALIDITY_DAYS = 30


#    print("=== Data Plans Generator for Print VTU ===\n")
#    print("Current Configuration:")
#    print(f"Network Prices per GB: {NETWORK_PRICES}")
#    print(f"Data Sizes: {DATA_SIZES} GB")
#    print(f"Validity: {VALIDITY_DAYS} Days")
#    print("\n" + "="*50)
#    print("GENERATED DATA PLANS CODE:")
#    print("="*50)

    # Generate the JavaScript code
    js_code = "const dataPlans = {\n"
    
    for network, price_per_gb in NETWORK_PRICES.items():
        js_code += f"  {network}: [\n"
        
        for size in DATA_SIZES:
            total_price = int(price_per_gb * size)
            formatted_price = f"{total_price:,}"
            js_code += f'    {{ name: "{size}GB - {VALIDITY_DAYS} Days - ₦{formatted_price}", value: {total_price} }},\n'
        
        js_code += "  ],\n"
    
    js_code += "};"
    
    print(js_code)
    
#    print("\n" + "="*50)
#    print("COPY THE ABOVE CODE AND REPLACE YOUR CURRENT dataPlans OBJECT")
#    print("="*50)

if __name__ == "__main__":
    generate_data_plans()





