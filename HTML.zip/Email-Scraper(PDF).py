import os
import re
import sys
import traceback
from datetime import datetime
from PyPDF2 import PdfReader

# ====== CONFIG ======
Single_File = True
PDF_DIR = os.path.join(os.getcwd(), "PDF")
OUTPUT_DIR = os.path.join(os.getcwd(), "JSON")
fileName = "PDF-Emails.txt"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, fileName)

# ====== COLOR CONFIG ======
colors = {
    "reset": '\x1b[0m',
    "bright": '\x1b[1m',
    "green": '\x1b[32m',
    "yellow": '\x1b[33m',
    "blue": '\x1b[34m',
    "magenta": '\x1b[35m',
    "cyan": '\x1b[36m',
    "red": '\x1b[31m',
    "white": '\x1b[37m'
}

# ====== UTILITY ======
def print_log(message, color="reset"):
    print(f"{colors.get(color, colors['reset'])}{message}{colors['reset']}")

def extract_emails_from_text(text):
    # Improved regex: no digits after final dot
    pattern = r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}'
    return re.findall(pattern, text)

def ensure_dir(path):
    try:
        if not os.path.exists(path):
            os.makedirs(path)
            print_log(f"Created directory: {path}", "magenta")
    except Exception as e:
        print_log(f"Failed to create directory {path}: {e}", "red")
        sys.exit(1)

# ====== MAIN ======
def main():
    start_time = datetime.now()
    start_str = start_time.strftime("%d/%m/%Y %I:%M %p")
    print_log(f"Script started at: {start_str}", "bright")

    ensure_dir(PDF_DIR)
    ensure_dir(OUTPUT_DIR)

    try:
        pdf_files = [f for f in os.listdir(PDF_DIR) if f.lower().endswith(".pdf")]
        total_files = len(pdf_files)
        if total_files == 0:
            print_log("No PDF files found in the PDF directory.", "yellow")
            return

        email_counter = 1
        all_emails = []
        total_emails_extracted = 0

        for idx, pdf_file in enumerate(pdf_files, 1):
            pdf_path = os.path.join(PDF_DIR, pdf_file)
            print_log(f"\nProcessing file {idx}/{total_files}: {pdf_file}", "cyan")
            try:
                reader = PdfReader(pdf_path)
                text_content = ""
                for page_num, page in enumerate(reader.pages, 1):
                    try:
                        page_text = page.extract_text() or ""
                        text_content += page_text
                    except Exception:
                        print_log(f"Warning: Failed to extract text from page {page_num} of {pdf_file}", "yellow")
                        continue

                if not text_content.strip():
                    print_log(f"No text found in {pdf_file}. Skipping.", "yellow")
                    continue

#                text_content = re.sub(
#                    r'([a-zA-Z])([A-Za-z0-9_.+-]+@[A-Za-z0-9-]+\.[A-Za-z]{2,})',
#                    r'\1 \2',
#                    text_content
#                )

                emails = extract_emails_from_text(text_content)
                num_emails = len(emails)
                if num_emails == 0:
                    print_log(f"No emails found in {pdf_file}.", "red")
                else:
                    total_emails_extracted += num_emails
                    # Rotate colors for per-file log
                    log_colors = ["magenta"]
                    color = log_colors[idx % len(log_colors)]
                    print_log(f"Extracted {num_emails} emails from {pdf_file}", color)

                    if Single_File:
                        all_emails.extend(emails)
                    else:
                        out_file = os.path.join(OUTPUT_DIR, f"emails{email_counter}.txt")
                        try:
                            with open(out_file, "w", encoding="utf-8") as f:
                                f.write("\n".join(emails))
                            color = log_colors[email_counter % len(log_colors)]
                            print_log(f"Saved {num_emails} emails to {out_file}", color)
                        except Exception as e:
                            print_log(f"Failed to save {out_file}: {e}", "red")
                        email_counter += 1

            except Exception as e:
                print_log(f"Failed to process {pdf_file}: {e}", "red")
                traceback.print_exc()

        # Save all emails if Single_File mode
        if Single_File and all_emails:
            try:
                with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
                    f.write("\n".join(all_emails))
                print_log(f"\nAll emails saved to {OUTPUT_FILE}", "green")
            except Exception as e:
                print_log(f"Failed to save emails to {OUTPUT_FILE}: {e}", "red")

        # Summary
        print_log(f"\nSummary: Extracted {total_emails_extracted} emails.", "bright")
        print_log(f"\nSaved {total_emails_extracted} Emails to: {fileName}", "bright")

        end_time = datetime.now()
        end_str = end_time.strftime("%d/%m/%Y %I:%M %p")
        duration = end_time - start_time
        h, remainder = divmod(duration.total_seconds(), 3600)
        m, s = divmod(remainder, 60)
        print_log(f"Script ended at: {end_str}", "bright")
        print_log(f"Time used: {int(h):02d}_{int(m):02d}_{int(s):02d}", "bright")

        print_log("\nProcessing complete!", "green")

    except Exception as e:
        print_log(f"Unexpected error: {e}", "red")
        traceback.print_exc()

if __name__ == "__main__":
    main()


