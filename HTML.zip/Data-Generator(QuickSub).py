def generate_data_plans():
    NETWORK_PRICES = {
        'MTN': {
            'All': 0,
            'Daily': 100,
            'Weekly': 280,
            'Monthly': 300
        },
        'Airtel': {
            'All': 0,
            'Daily': 100,
            'Weekly': 260,
            'Monthly': 290
        },
        'Glo': {
            'All': 0,
            'Daily': 100,
            'Weekly': 250,
            'Monthly': 270
        },
        '9Mobile': {
            'All': 0,
            'Daily': 100,
            'Weekly': 240,
            'Monthly': 250
        }
    }

    # Data sizes for each category (6 items each to match your HTML structure)
    ALL_SIZES = [1, 1, 1, 1, 1, 1]
    DAILY_SIZES = [0.1, 0.2, 0.5, 1, 1.5, 2]
    WEEKLY_SIZES = [1, 2, 3, 5, 7, 10]
    MONTHLY_SIZES = [1, 3, 5, 7, 10, 15]

#    print("=== Data Plans Generator for QuickSub ===")
#    print("\nGENERATED JAVASCRIPT CODE:")
#    print("=" * 60)

    # Generate the JavaScript bundlePrices object
    js_code = "const bundlePrices = {\n"
    
    for network in NETWORK_PRICES:
        js_code += f"  {network}: {{\n"
        
        # All category - set to 0 (you'll manually update these)
        js_code += "    All: ["
        all_prices = ['0'] * 6  # Six zeros for manual configuration
        js_code += ", ".join(all_prices)
        js_code += "],\n"
        
        # Daily plans - simple fixed prices
        js_code += "    Daily: ["
        daily_prices = []
        for size in DAILY_SIZES:
            # Simple pricing: 100, 200, 500, 1000, 1500, 2000
            price = int(NETWORK_PRICES[network]['Daily'] * (size * 10))
            daily_prices.append(str(price))
        js_code += ", ".join(daily_prices)
        js_code += "],\n"
        
        # Weekly plans  
        js_code += "    Weekly: ["
        weekly_prices = []
        for size in WEEKLY_SIZES:
            price = int(NETWORK_PRICES[network]['Weekly'] * size)
            weekly_prices.append(str(price))
        js_code += ", ".join(weekly_prices)
        js_code += "],\n"
        
        # Monthly plans
        js_code += "    Monthly: ["
        monthly_prices = []
        for size in MONTHLY_SIZES:
            price = int(NETWORK_PRICES[network]['Monthly'] * size)
            monthly_prices.append(str(price))
        js_code += ", ".join(monthly_prices)
        js_code += "]\n"
        
        js_code += "  },\n"
    
    js_code += "};"
    
    print(js_code)
    
    # Also generate the durations object
#    print("\n" + "=" * 60)
#    print("DURATIONS CONFIGURATION:")
#    print("=" * 60)
    
    durations_code = """const durations = {
  All: ["1 Day", "1 Day", "7 Days", "7 Days", "30 Days", "30 Days"],
  Daily: ["1 Day", "1 Day", "1 Day", "1 Day", "1 Day", "1 Day"],
  Weekly: ["7 Days", "7 Days", "7 Days", "7 Days", "7 Days", "7 Days"],
  Monthly: ["30 Days", "30 Days", "30 Days", "30 Days", "30 Days", "30 Days"]
};"""
    
#    print(durations_code)
    
#    print("\n" + "=" * 60)

if __name__ == "__main__":
    generate_data_plans()

